<div class="art-post">
<div class="art-post-body">
<div class="art-post-inner art-article">
<h2 class="art-postheader">Selamat Datang</h2>
<div class="art-postcontent">
<img src="images/pencernaan.jpg" style="float:right;" />
<p>Sistem pakar diagnosa penyakit lambung digunakan untuk mendiagnosa gejala-gejala yang mungkin terjadi pada gangguan pencernaan khususnya mengenai penyakit yang terdapat pada lambung.</p>
<p><h3>Untuk mulai proses diagnosa silahkan klik Mulai Diagnosa</h3></p>
<p><a href="index.php?top=pasien_add_fm.php" class="active"><span class="l"></span><span class="r"></span><span class="t"><strong>Mulai Diagnosa</strong></span></a></p>
</div>
<div class="cleared"></div>
</div>
		<div class="cleared"></div>
    </div>
</div>