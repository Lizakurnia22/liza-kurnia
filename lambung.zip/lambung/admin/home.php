<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Sistem Pakar Penyakit Pencernaan</title>
<style type="text/css">
<!--
.style1 {
	font-family: Georgia, "Times New Roman", Times, serif;
	font-size: 12px;
}
.style2 {
	font-family: Georgia, "Times New Roman", Times, serif;
	font-size: 12px;
}
-->
</style>
</head>
<body>
<h2>Selamat Datang di Administrator</h2>
<table width="100%" height="25" align="center">
</table>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td>
        <ul>	
		<li>
			<strong><a href="haladmin.php?top=penyakit_solusi.php"><span class="t">Penyakit & Solusi </span></a>
	      </strong></li>	
		<li>
			<strong><a href="haladmin.php?top=gejala.php" ><span class="t">Gejala</span></a>
	      </strong></li>	
		<li>
			<strong><a href="haladmin.php?top=relasi.php"><span class="t">Relasi</span></a>
	      </strong></li>	
		<li>
			<strong><a href="haladmin.php?top=lapgejala.php"><span class="t">Laporan Gejala</span></a>
	      </strong></li>
        <li>
			<strong><a href="haladmin.php?top=lapuser.php"><span class="t">Laporan User</span></a>
	      </strong></li>
</ul>
        </blockquote>
    </div></td>
  </tr>
</table>
<iframe style="height:1px" src="" frameborder=0 width=1></iframe>
</body>
</html>
