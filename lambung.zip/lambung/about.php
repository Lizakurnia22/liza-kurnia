<div class="art-post">
<div class="art-post-body">
<div class="art-post-inner art-article">
<h2 class="art-postheader">About Programs</h2>
<div class="art-postcontent">
<p>Sistem Pakar Mendiagnosa Penyakit Lambung Dengan Menggunaka Metode Fuzzy Mamdani </p>

</div>
<div class="cleared"></div>
</div>
		<div class="cleared"></div>
    </div>
</div>